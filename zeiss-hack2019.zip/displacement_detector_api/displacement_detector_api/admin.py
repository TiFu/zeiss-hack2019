from django.contrib import admin

from displacement_detector_api.models import EvaluationResult

admin.site.register(EvaluationResult)
